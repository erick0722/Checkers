Erick Yip
30028293
449 Asg1 - Part 2

Files submitted:

ErickYip_Black_AI.hs: 
    The black AI that has my name included. Imports Checkers.hs, Apply_Moves.hs and Moves.hs

ErickYip_Red_AI.hs:
    The red AI that has my name included, similar to the black ai, it also imports Checkers.hs, Apply_Moves.hs and Moves.hs

Apply_Moves.hs: 
    Includes apply_move :: Move -> GameState -> GameStateapply_moves along with other helper functions, it also need to import Moves.hs

Moves.hs:
    Includes moves :: GameState -> [Move] and all its helper functions, imports Gamelogic.hs

CheckersErickYip.hs:
    Not sure if this one is needed, but it includes all the function from the 4 modules above. Imports GameLogic.hs and Checkers.hs


PS: The program works perfectly on my computer. If anything does not work please email me, Thanks!