{-

Erick Yip
30028293
449 Asg1 - Part 2

-}

module ErickYip_Red_AI where

import Checkers
import Apply_Moves
import Moves

redAI :: GameState -> Move
redAI st = fst (last (sort_heuristic (getMoves st Red (moves st))))

getMoves :: GameState -> Status -> [Move] -> [(Move,Int)]
getMoves st stat [] = []
getMoves st stat (x:xs) = (x, (abMinPrune (apply_move x st) stat (-1000) (1000) 8)) : (getMoves st stat xs) 

get_heuristic :: GameState -> Status -> Int
get_heuristic st stat
    | stat == Red = length (_redPieces st) - length (_blackPieces st) + 2 * (length (_redKings st)  - length (_blackKings st))
    | otherwise = length (_blackPieces st) - length (_redPieces st) + 2 * (length (_blackKings st)  - length (_redKings st))

sort_heuristic :: [(Move,Int)] -> [(Move,Int)]
sort_heuristic [] = []
sort_heuristic (x:xs)
    | xs == [] = [x]
    | snd x > snd (head xs) = head xs : sort_heuristic (x : tail xs)
    | otherwise = x : sort_heuristic xs

abMaxPrune :: GameState -> Status -> Int -> Int -> Int -> Int
abMaxPrune st stat alpha beta depth
    | alpha == beta = alpha
    | depth == 0 = min (max (get_heuristic st stat) alpha) beta
    | otherwise = abMaxPrune' st stat (moves st) alpha beta depth

abMaxPrune' :: GameState -> Status -> [Move] -> Int -> Int -> Int -> Int
abMaxPrune' st stat [] alpha beta depth = alpha
abMaxPrune' st stat (x:xs) alpha beta depth = abMaxPrune' st stat xs newAlpha beta depth
    where
        newAlpha = abMinPrune (apply_move x st) stat alpha beta (depth - 1)

abMinPrune :: GameState -> Status -> Int -> Int -> Int -> Int
abMinPrune st stat alpha beta depth
    | alpha == beta = beta
    | depth == 0 = max (min (get_heuristic st stat) beta) alpha
    | otherwise = abMinPrune' st stat (moves st) alpha beta depth

abMinPrune' :: GameState -> Status -> [Move] -> Int -> Int -> Int -> Int
abMinPrune' st stat [] alpha beta depth = beta
abMinPrune' st stat (x:xs) alpha beta depth = abMinPrune' st stat xs alpha newBeta depth
    where
        newBeta = abMaxPrune (apply_move x st) stat alpha beta (depth - 1)
